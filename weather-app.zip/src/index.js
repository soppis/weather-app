import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import * as serviceWorker from './serviceWorker';


const API = 'http://api.openweathermap.org/data/2.5/weather?q=Tampere,fi&APPID=9fe9fe77a6c9206df22230f418774584';


class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      hits: [],
    };
  }

  componentDidMount() {
    fetch(API)
      .then(response => response.json())
      .then(data => this.setState({ hits: data.hits }));
  }

}

export default App;


class Weather extends React.Component {
  constructor(props) {
    super(props);
    this.state = {value: ''};


    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({value: event.target.value});
  }

  handleSubmit(event) {
    alert('Paikkanunnan: ' + this.state.value+' sää');



    event.preventDefault();
  }
  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <label>
          Syötä paikkakunta:
          <input type="text" value={this.state.value} onChange={this.handleChange} />
        </label>
        <input type="submit" value="Hae" />
      </form>
    );
  }




}








ReactDOM.render(
  <Weather />,
  document.getElementById('root')
);

 
//ReactDOM.render(e, document.getElementById('root'));

 

// If you want your app to work offline and load faster, you can change

// unregister() to register() below. Note this comes with some pitfalls.

// Learn more about service workers: http://bit.ly/CRA-PWA

serviceWorker.unregister();